package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Customer;
import com.example.demo.service.CustomerService;

@RestController
@RequestMapping("/demo")
public class CustomerController {
	@Autowired
	private CustomerService service;
	
	@GetMapping("/checking")
	public String hello() {
		return "hello Teams";
	}
	
	@GetMapping("/findAll")
	public List<Customer> getAll(){
		System.err.println("method is loading");
		return service.getAll();
	}
}

package com.onlinebank.dao;

public interface CheckBalDao {

}

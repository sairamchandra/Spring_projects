package com.onlinebank.dao;

import java.util.List;

import com.onlinebank.profile.MyProfile;

public interface ProfileDao {
	

public MyProfile ShowProfile(int id);
}

package com.onlinebank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.onlinebank.dao.ClientDao;
import com.onlinebank.model.Client;


@Controller
public class ClientController {
	@Autowired
	ClientDao clientdao;


//	@GetMapping(value = "/showclients")
//	public String showClients() {
//
//		return "clients";
//	}
	@GetMapping(value = "/registerhere")
	public String showClient(Model model) {
		Client client=new Client();
		model.addAttribute("client", client);
		return "addAccount";
	}

	@PostMapping(value = "/saveAccount")
	public String SaveClient(Client client) {
		clientdao.saveAccount(client);
		return "saved";
	}
}

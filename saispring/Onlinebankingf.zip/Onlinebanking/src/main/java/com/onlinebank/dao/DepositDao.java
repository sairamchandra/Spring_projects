package com.onlinebank.dao;

import com.onlinebank.model.Deposit;

public interface DepositDao {
int addamt(Deposit depo);
}

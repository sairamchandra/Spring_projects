package com.onlinebank.dao;

import com.onlinebank.model.AdminLogin;

public interface AdminDao {
AdminLogin admlogin(AdminLogin adminlog);
}

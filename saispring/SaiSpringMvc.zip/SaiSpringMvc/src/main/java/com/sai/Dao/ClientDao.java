package com.sai.Dao;

import com.sai.model.Client;

public interface ClientDao {
public void saveClient(Client client);
}

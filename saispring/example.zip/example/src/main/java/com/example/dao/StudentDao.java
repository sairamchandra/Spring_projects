package com.example.dao;

import com.example.model.Student;

public interface StudentDao {
public void saveStudent(Student stud);
}

package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.dao.StudentDao;
import com.example.model.Student;

@Controller
public class HelloController {
	@Autowired
	StudentDao stddao;
	@GetMapping(value = "/showform")
	public String saveResult(Model model) {
		Student sd=new Student();
		model.addAttribute("student", sd);
		return "register";
	}
	@ResponseBody
	@PostMapping(value = "save")
	public String saveResults(Student std) {
		stddao.saveStudent(std);
		return "registerd";
	}
}

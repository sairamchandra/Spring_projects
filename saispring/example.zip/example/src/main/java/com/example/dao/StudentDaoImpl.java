package com.example.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.model.Student;
@Repository
public class StudentDaoImpl implements StudentDao {
@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public void saveStudent(Student stud) {
String sql="insert into students1(fname,lname,age,city) values(?,?,?,?)";
jdbcTemplate.update(sql,stud.getFname(),stud.getLname(),stud.getAge(),stud.getCity());
	}

}

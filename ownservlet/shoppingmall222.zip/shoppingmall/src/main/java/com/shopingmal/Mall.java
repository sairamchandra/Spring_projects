package com.shopingmal;

import org.springframework.stereotype.Component;

@Component
public interface Mall {
	public void shop();
}

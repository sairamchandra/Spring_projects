package com.annota;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContextExtensionsKt;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.shopingmal.Mall;

public class AnnoApp {

	public static void main(String[] args) {

		ApplicationContext apli=new AnnotationConfigApplicationContext(Config.class);
		AutoClass com= apli.getBean("autoclass",AutoClass.class);
		System.out.println(com);
		
//		Mall m1=(Mall) apli.getBean("deemart");
//		m1.shop();
//		Software s=apli.getBean("software",Software.class);
//		s.Development();
	}

}

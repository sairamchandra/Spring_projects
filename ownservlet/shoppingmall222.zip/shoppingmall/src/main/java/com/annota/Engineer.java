package com.annota;

import org.springframework.stereotype.Component;

@Component
public interface Engineer {
void Development();
}

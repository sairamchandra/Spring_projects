package com.annota;

import org.springframework.stereotype.Component;

@Component
public class Hardware implements Engineer {

	public void Development() {
System.out.println("i am hardware eng");
	}

}

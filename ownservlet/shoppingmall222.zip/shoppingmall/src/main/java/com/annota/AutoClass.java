package com.annota;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class AutoClass {
@Autowired
Company company;
public Company getCompany() {
	return company;
}
public void setCompany(Company company) {
	this.company = company;
}
String aut01;
int id;
public AutoClass(String aut01, int id) {
	super();
	this.aut01 = aut01;
	this.id = id;
}

@Override
public String toString() {
	return "AutoClass [company=" + company + ", aut01=" + aut01 + ", id=" + id + "]";
}


}
